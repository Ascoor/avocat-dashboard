// import React from 'react';

// const TopTools = ({ saveFile, createNew, importfile, exportFile }) => {
//   return (
//     <div className="top-tools">
//       {/* Existing Buttons */}
//       {/* ... */}
//       <button onClick={saveFile} style={{ backgroundColor: 'lightgreen' }}>
//         Save
//       </button>
//       <button onClick={createNew} style={{ backgroundColor: 'lightblue' }}>
//         New
//       </button>
//       <button onClick={importfile} style={{ backgroundColor: 'lightpink' }}>
//         Insert
//       </button>
//       <button onClick={exportFile} style={{ backgroundColor: 'lightgrey' }}>
//         Export
//       </button>
//     </div>
//   );
// };

// export default TopTools;
