// import React from 'react';
// import './SideTools.css';

// const Sidebar = ({ setStyle }) => {
//   const applyColor = (color) => {
//     setStyle('color', color);
//   };

//   const applyFontSize = (size) => {
//     setStyle('fontSize', size);
//   };

//   return (
//     <div className="sidebar">
//       <button onClick={() => applyColor('red')}>Red</button>
//       <button onClick={() => applyColor('green')}>Green</button>
//       <button onClick={() => applyColor('blue')}>Blue</button>

//       <button onClick={() => applyFontSize('12px')}>Small</button>
//       <button onClick={() => applyFontSize('16px')}>Medium</button>
//       <button onClick={() => applyFontSize('20px')}>Large</button>

//       {/* Add more tools */}
//     </div>
//   );
// };

// export default Sidebar;
