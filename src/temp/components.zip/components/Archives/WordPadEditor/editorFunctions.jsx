// // editorFunctions.js
// export const initialStyles = () => ({
//   fontWeight: 'normal',
//   fontStyle: 'normal',
//   textDecoration: 'none',
//   textAlign: 'left',
//   color: 'black',
//   fontFamily: 'Arial',
// });

// export const toggleStyle = (setStyles, key, activeValue, defaultValue) => {
//   setStyles((prevStyles) => ({
//     ...prevStyles,
//     [key]: prevStyles[key] === activaeValue ? defaultValue : activeValue,
//   }));
// };

// export const setStyle = (setStyles, key, value) => {
//   setStyles((prevStyles) => ({ ...prevStyles, [key]: value }));
// };
