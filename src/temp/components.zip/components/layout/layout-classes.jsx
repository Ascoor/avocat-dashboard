
export const shellContainer = "mx-auto w-full max-w-6xl";
export const shellSectionSpacing = "flex-1 overflow-x-hidden pb-10 pt-6";